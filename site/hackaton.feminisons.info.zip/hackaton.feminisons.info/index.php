<?php
 
$data_to_be_pass=$_POST['data_to_be_pass'];
 
$res="Data Passed Successfully: ".$data_to_be_pass;
echo json_encode($res);
 
 ?>